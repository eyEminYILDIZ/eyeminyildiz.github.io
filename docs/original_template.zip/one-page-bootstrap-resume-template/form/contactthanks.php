<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Strict//EN">

<head>
	<title>Message Sent!</title>
</head>

<body>	
			
	<h2>Your message has been sent!</h2>

	<p><a href="index.html">Back to Home</a></p>

</body>

</html>